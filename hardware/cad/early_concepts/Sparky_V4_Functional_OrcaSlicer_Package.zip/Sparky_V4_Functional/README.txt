SPARKY V4 FUNCTIONAL ENCLOSURE PROTOTYPE

This is the next step after the V3 visual prototype. V4 adds hollow printable shells, a display aperture/retention geometry, speaker mounting/grille geometry, USB-C rear reliefs, and basic internal mounting features.

Designed around:
- Head: 96 x 58 x 76 mm
- Body: 68 x 48 x 62 mm
- Display: 64.3 x 35 x 26.5 mm nominal
- Display clearance envelope: about 68 x 39 x 32 mm
- Speaker: 40 mm, 8 ohm, 2 W
- ESP32-S3 board: 50.1 x 13 mm envelope
- M3 self-tapping screws, approximately 2.5 mm pilot holes
- USB-C powered; no internal battery

OPEN FIRST IN ORCASLICER:
- Sparky_V4_layout.stl

PRINTABLE PARTS:
- Sparky_V4_head_front.stl
- Sparky_V4_head_rear.stl
- Sparky_V4_display_bezel.stl
- Sparky_V4_body_front.stl
- Sparky_V4_body_rear.stl
- Sparky_V4_speaker_grille.stl

assembly.stl is only a visual check.

IMPORTANT:
- Exact connector/header locations for the ESP32-S3 and exact MAX98357A/INMP441 breakout mechanical drawings were not supplied. Internal rails/pads intentionally leave room for adjustment.
- Verify the actual MAX7219 module PCB/header depth before finalizing the head.
- Print a small display/head fit test and speaker mount test before printing the full enclosure.
- This is a prototype CAD revision, not a production-certified enclosure.

Suggested print starting point: PLA, 0.20 mm layer, 3-4 walls, 15-20% infill.
