$fn=24;

// SPARKY V4 - functional printable enclosure prototype
// Units: mm. Designed around user-supplied electronics dimensions.

// ---------- Core dimensions ----------
head_w=96; head_d=58; head_h=76; head_r=9;
body_w=68; body_d=48; body_h=62; body_r=9;
wall=2.6;

// Display: Raspberry Pi-compatible 8x16 MAX7219
lcd_w=64.3; lcd_h=35; lcd_d=26.5;
disp_clear_w=68; disp_clear_h=39; disp_clear_d=32;

speaker_d=40; speaker_mount_d=46;

// Generic board envelope
esp_w=50.1; esp_d=13;

// Fasteners
screw_d=2.5; boss_od=7; boss_h=9;

// ---------- Helpers ----------
module rounded_box(x,y,z,r){
    minkowski(){
        cube([x-2*r,y-2*r,z-2*r],center=true);
        sphere(r=r);
    }
}

module shell_box(x,y,z,r,t){
    difference(){
        rounded_box(x,y,z,r);
        rounded_box(x-2*t,y-2*t,z-2*t,max(0.8,r-t));
    }
}

module cyl_y(d,depth){
    rotate([90,0,0]) cylinder(d=d,h=depth,center=true);
}

// ---------- HEAD ----------
// Head centered around Z=0 for individual printing.
module head_outer_shell(){
    difference(){
        shell_box(head_w,head_d,head_h,head_r,wall);
        // Open bottom so the head can seat over the body neck / wiring.
        translate([0,0,-head_h/2-2]) cube([80,50,12],center=true);
        // Front display aperture. Front is negative Y.
        translate([0,-head_d/2-1,4]) cube([disp_clear_w,6,disp_clear_h],center=true);
        // Rear cable/service opening.
        translate([0,head_d/2+1,-20]) cube([18,6,9],center=true);
        // Two USB-C reliefs on rear, matching the two-port ESP32 concept.
        translate([-14,head_d/2+1,-2]) cube([11,6,8],center=true);
        translate([14,head_d/2+1,-2]) cube([11,6,8],center=true);
    }
}

module display_rails(){
    // Horizontal lower/upper rails behind front aperture. Generous fit.
    for(z=[-15.5,15.5])
        translate([0,-head_d/2+wall+disp_clear_d/2,z+4])
            cube([disp_clear_w+3,3,3],center=true);
    // Side stops.
    for(x=[-disp_clear_w/2-1.5,disp_clear_w/2+1.5])
        translate([x,-head_d/2+wall+disp_clear_d/2,4])
            cube([3,3,disp_clear_h+3],center=true);
}

module head_screw_bosses(){
    // Rear-shell bosses near corners, kept clear of display volume.
    for(x=[-38,38]) for(z=[-28,28])
        translate([x,8,z]){
            difference(){
                cylinder(d=boss_od,h=boss_h,center=false);
                cylinder(d=screw_d,h=boss_h+0.5,center=false);
            }
        }
}

module head_front(){
    // Front shell: shallow front half + bezel/rail support.
    intersection(){
        head_outer_shell();
        translate([0,-15,0]) cube([120,30,100],center=true);
    }
    display_rails();
}

module head_rear(){
    intersection(){
        head_outer_shell();
        translate([0,15,0]) cube([120,30,100],center=true);
    }
    head_screw_bosses();
}

module display_bezel(){
    difference(){
        cube([72,4,43],center=true);
        cube([68,8,39],center=true);
    }
}

// ---------- BODY ----------
module body_outer_shell(){
    difference(){
        shell_box(body_w,body_d,body_h,body_r,wall);
        // Bottom opening/service relief.
        translate([0,0,-body_h/2-2]) cube([54,40,8],center=true);
        // Rear USB/power cable opening.
        translate([0,body_d/2+1,-12]) cube([22,6,10],center=true);
    }
}

module speaker_mount(){
    // Front-facing 40mm speaker cavity and four mounting tabs/holes.
    translate([0,-body_d/2-1,8]){
        difference(){
            cylinder(d=speaker_mount_d,h=5,center=true, $fn=24);
            cylinder(d=speaker_d+2,h=8,center=true, $fn=24);
        }
        for(a=[45,135,225,315])
            rotate([0,0,a]) translate([23,0,0]) difference(){
                cylinder(d=6,h=5,center=true);
                cylinder(d=2.8,h=7,center=true);
            }
    }
}

module speaker_grille(){
    difference(){
        rounded_box(50,3,50,5);
        // 7 x 7 staggered acoustic holes.
        for(ix=[-3:3]) for(iz=[-3:3])
            translate([ix*6.2,-2,iz*6.2]) rotate([90,0,0]) cylinder(d=2.8,h=6,center=true,$fn=20);
    }
}

module body_bosses(){
    for(x=[-27,27]) for(y=[-17,17])
        translate([x,y,-20]){
            difference(){
                cylinder(d=boss_od,h=boss_h);
                cylinder(d=screw_d,h=boss_h+0.5);
            }
        }
}

module board_rails(){
    // ESP32 horizontal slide rails; intentionally generous until exact board hole spacing is confirmed.
    translate([-25,-2,10]) cube([54,3,3],center=true);
    translate([-25,12,10]) cube([54,3,3],center=true);
}

module amp_pad(){
    // MAX98357A mounting platform with flexible tie/adhesive clearance.
    translate([18,7,-8]) cube([18,18,3],center=true);
}

module mic_pad(){
    // INMP441 pad positioned away from speaker cavity.
    translate([-18,7,-8]) cube([18,18,3],center=true);
}

module body_front(){
    intersection(){
        body_outer_shell();
        translate([0,-12,0]) cube([100,24,90],center=true);
    }
    speaker_mount();
}

module body_rear(){
    intersection(){
        body_outer_shell();
        translate([0,12,0]) cube([100,24,90],center=true);
    }
    body_bosses();
    board_rails();
    amp_pad();
    mic_pad();
}

// ---------- Limbs / chest ----------
module arm(){ rounded_box(14,20,14,5); }
module foot(){ rounded_box(24,30,10,4); }
module lightning(){
    union(){
        translate([-4,0,5]) cube([8,3,24],center=true);
        translate([3,0,-6]) cube([8,3,20],center=true);
        translate([0,0,-16]) cube([7,3,12],center=true);
    }
}

// ---------- Component proxies ----------
module display_proxy(){ color("red") cube([lcd_w,lcd_d,lcd_h],center=true); }
module esp_proxy(){ color("green") cube([esp_w,esp_d,3],center=true); }
module speaker_proxy(){ color("gray") rotate([90,0,0]) cylinder(d=speaker_d,h=12,center=true); }

// ---------- Print layouts ----------
module layout(){
    // Parts separated for OrcaSlicer inspection.
    translate([-62,-55,0]) head_front();
    translate([45,-55,0]) head_rear();
    translate([-45,20,0]) body_front();
    translate([45,20,0]) body_rear();
    translate([-10,72,3]) display_bezel();
    translate([55,72,2]) speaker_grille();
    translate([-62,72,7]) arm();
    translate([-43,72,7]) arm();
    translate([35,72,5]) foot();
    translate([65,72,5]) foot();
}

module assembly_preview(){
    // Approximate assembled view only.
    translate([0,0,65]) head_outer_shell();
    translate([0,0,0]) body_outer_shell();
    translate([-42,0,5]) arm();
    translate([42,0,5]) arm();
    translate([-17,0,-36]) foot();
    translate([17,0,-36]) foot();
    translate([0,-30,4]) lightning();
}

// ---------- Selector ----------
part="layout";
if(part=="layout") layout();
if(part=="head_front") head_front();
if(part=="head_rear") head_rear();
if(part=="display_bezel") display_bezel();
if(part=="body_front") body_front();
if(part=="body_rear") body_rear();
if(part=="speaker_grille") speaker_grille();
if(part=="assembly") assembly_preview();
