// Sparky V3 parametric starter
$fn=64;
display_w=64.3; display_h=35; display_depth_nom=26.5; display_cavity_depth=32;
head_w=96; head_d=58; head_h=76; body_w=68; body_d=48; body_h=62;
module rounded_box(x,y,z,r=5){ minkowski(){ cube([x-2*r,y-2*r,z-2*r],center=true); sphere(r); } }
module head(){rounded_box(head_w,head_d,head_h,9);}
module body(){rounded_box(body_w,body_d,body_h,9);}
module arm(){rounded_box(14,20,14,5);}
module foot(){rounded_box(24,30,10,4);}
module assembly(){translate([0,0,60])head(); body(); translate([-42,0,0])arm(); translate([42,0,0])arm(); translate([-17,0,-37])foot(); translate([17,0,-37])foot();}
assembly();
