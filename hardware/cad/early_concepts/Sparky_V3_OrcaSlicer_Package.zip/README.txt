SPARKY V3 ORCASLICER PACKAGE

Open Sparky_V3_Print_Layout.stl first in OrcaSlicer.
Sparky_V3_Assembly.stl is a visual assembled prototype.

Design targets:
- MAX7219 Raspberry Pi 8x16: 64.3 x 35 x 26.5 mm nominal
- Display cavity target: about 68 x 39 x 32 mm for tolerance
- ESP32-S3: 50.1 x 13 mm nominal
- 40 mm 8-ohm 2 W speaker
- USB-C power only; no internal battery
- M3 x 8 mm enclosure screws

IMPORTANT: This is a first fit/visual prototype. Verify real component dimensions, especially connector/header positions, before final production CAD.
Recommended initial print: PLA, 0.4 mm nozzle, 0.16-0.20 mm layers, 3 walls, 15-20% infill.
